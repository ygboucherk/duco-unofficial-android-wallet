package com.duinocoin.wallet;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Button;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class SendtxActivity extends AppCompatActivity {
	
	
	private Toolbar _toolbar;
	private String balanceurl = "";
	private double balance = 0;
	private String sendtxurl = "";
	
	private TextView title;
	private EditText recipient;
	private EditText amount;
	private Button button1;
	
	private RequestNetwork getbalance;
	private RequestNetwork.RequestListener _getbalance_request_listener;
	private AlertDialog.Builder confirm;
	private RequestNetwork sendtx;
	private RequestNetwork.RequestListener _sendtx_request_listener;
	private Intent backhome = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sendtx);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		title = (TextView) findViewById(R.id.title);
		recipient = (EditText) findViewById(R.id.recipient);
		amount = (EditText) findViewById(R.id.amount);
		button1 = (Button) findViewById(R.id.button1);
		getbalance = new RequestNetwork(this);
		confirm = new AlertDialog.Builder(this);
		sendtx = new RequestNetwork(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (balance < Double.parseDouble(amount.getText().toString())) {
					SketchwareUtil.showMessage(getApplicationContext(), "Not enough balance...");
				}
				else {
					confirm.setTitle("Confirm");
					confirm.setMessage("Do you confirm sending ".concat(amount.getText().toString()).concat(" DUCO to ".concat(recipient.getText().toString().concat(" ? "))));
					confirm.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							sendtxurl = "http://".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/rpc.txt").concat("/wallet/sendtx/")).concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/username.txt").concat("/".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/password.txt"))).concat("/".concat(recipient.getText().toString().concat("/".concat(amount.getText().toString())))));
							sendtx.startRequestNetwork(RequestNetworkController.GET, sendtxurl, "", _sendtx_request_listener);
						}
					});
					confirm.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							SketchwareUtil.showMessage(getApplicationContext(), "Operation Cancelled");
						}
					});
					confirm.create().show();
				}
			}
		});
		
		_getbalance_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				balance = Double.parseDouble(_response);
				amount.setHint("Amount to send (avbl. ".concat(_response.concat(")")));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_sendtx_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), _response);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	private void initializeLogic() {
		balanceurl = "http://".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/rpc.txt").concat("/wallet/getbalance/")).concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/username.txt").concat("/".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/password.txt"))));
		getbalance.startRequestNetwork(RequestNetworkController.GET, balanceurl, "", _getbalance_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
