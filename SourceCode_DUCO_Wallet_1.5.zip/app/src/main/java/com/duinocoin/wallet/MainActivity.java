package com.duinocoin.wallet;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import android.widget.ImageView;
import java.util.Timer;
import java.util.TimerTask;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private String loginurl = "";
	private String rpcip = "";
	private double linenumber = 0;
	private String tosplit = "";
	
	private ArrayList<String> hosts = new ArrayList<>();
	
	private ImageView imageview1;
	
	private TimerTask splash;
	private Intent pass_spash = new Intent();
	private RequestNetwork checklogin;
	private RequestNetwork.RequestListener _checklogin_request_listener;
	private AlertDialog.Builder rpcerror;
	private RequestNetwork gethosts;
	private RequestNetwork.RequestListener _gethosts_request_listener;
	private RequestNetwork testconnection;
	private RequestNetwork.RequestListener _testconnection_request_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		checklogin = new RequestNetwork(this);
		rpcerror = new AlertDialog.Builder(this);
		gethosts = new RequestNetwork(this);
		testconnection = new RequestNetwork(this);
		
		_checklogin_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				FileUtil.writeFile("/data/data/com.duinocoin.wallet/rpc.txt", rpcip);
				SketchwareUtil.showMessage(getApplicationContext(), "Connected to ".concat(rpcip));
				if (_response.equals("OK")) {
					pass_spash.setAction(Intent.ACTION_VIEW);
					pass_spash.setClass(getApplicationContext(), WalletoverviewActivity.class);
					startActivity(pass_spash);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					pass_spash.setAction(Intent.ACTION_VIEW);
					pass_spash.setClass(getApplicationContext(), LoginActivity.class);
					startActivity(pass_spash);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_gethosts_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Hosts retrieved");
				tosplit = _response;
				_duco_testconnection();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				SketchwareUtil.showMessage(getApplicationContext(), "Error retrieving hosts");
			}
		};
		
		_testconnection_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				if (_response.equals("OK")) {
					FileUtil.writeFile("/data/data/com.duinocoin.wallet/rpc.txt", rpcip);
					_duco_login();
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				_duco_testconnection();
			}
		};
	}
	private void initializeLogic() {
		gethosts.startRequestNetwork(RequestNetworkController.GET, "https://raw.githubusercontent.com/ygboucherk/duino-coin-http-api/main/official_servers.txt", "", _gethosts_request_listener);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _splitlines (final String _entry) {
		tosplit = _entry;
		if (tosplit.contains("\n")) {
			tosplit = _entry;
			linenumber = tosplit.indexOf("\n");
			hosts.add(tosplit.substring((int)(0), (int)(linenumber)));
			tosplit = tosplit.substring((int)(linenumber), (int)(tosplit.length()));
		}
	}
	
	
	private void _duco_testconnection () {
		linenumber = tosplit.indexOf("\n");
		if (linenumber == tosplit.length()) {
			linenumber = tosplit.length();
		}
		if (tosplit.contains("\n") && tosplit.contains(":")) {
			rpcip = tosplit.substring((int)(0), (int)(linenumber));
			tosplit = tosplit.substring((int)(linenumber), (int)(tosplit.length()));
			if (tosplit.length() > 1) {
				tosplit = tosplit.substring((int)(1), (int)(tosplit.length()));
			}
			loginurl = "http://".concat(rpcip.concat("/wallet/login/test/test"));
			testconnection.startRequestNetwork(RequestNetworkController.GET, loginurl, "", _testconnection_request_listener);
		}
	}
	
	
	private void _duco_login () {
		if (FileUtil.isExistFile("/data/data/com.duinocoin.wallet/username.txt")) {
			loginurl = "http://".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/rpc.txt").concat("/wallet/login/")).concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/username.txt").concat("/".concat(FileUtil.readFile("/data/data/com.duinocoin.wallet/password.txt"))));
			checklogin.startRequestNetwork(RequestNetworkController.GET, loginurl, "", _checklogin_request_listener);
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Not logged in");
			pass_spash.setClass(getApplicationContext(), LoginActivity.class);
			pass_spash.setAction(Intent.ACTION_VIEW);
			startActivity(pass_spash);
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
